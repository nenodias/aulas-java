package org.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.model.Endereco;
import org.model.Pessoa;

public class PersistenciaBanco {
	
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("conexaoBanco");
		EntityManager entityManager = factory.createEntityManager();
		List<Pessoa> resultList = null;
		try{
			entityManager.getTransaction().begin();
			
			Query query = entityManager.createQuery(" FROM Pessoa p ");
			resultList = query.getResultList();
			
			
			
//			Pessoa pessoa = new Pessoa();
//			pessoa.setNome("Otário");
//			pessoa.setTelefone("(14)91234-5678");
//			
//			Endereco endereco = new Endereco();
//			endereco.setNumero("21");
//			endereco.setRua("Rua dos Desapegados");
//			endereco.setBairro("Limoeiro");
//			
//			pessoa.setEndereco(endereco);
//			
//			entityManager.persist(pessoa);
			
			entityManager.getTransaction().commit();
		}catch(Exception e){
			System.err.println(e.getMessage());
		}finally{
			entityManager.close();
			factory.close();
		}
		for (Pessoa pessoa : resultList) {
			System.out.println(pessoa);
		}
	}
	
}
